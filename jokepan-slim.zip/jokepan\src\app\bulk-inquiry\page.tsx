'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { products } from '@/data/products';
import { Mail, Phone, CheckCircle } from 'lucide-react';

export default function BulkInquiryPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    phone: '',
    productId: '',
    quantity: '',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Reset form
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        company: '',
        phone: '',
        productId: '',
        quantity: '',
        message: '',
      });

      // Reset success message after 5 seconds
      setTimeout(() => setSubmitted(false), 5000);
    } catch (error) {
      console.error('Error submitting form:', error);
    } finally {
      setLoading(false);
    }
  };

  const selectedProduct = formData.productId
    ? products.find(p => p.id === formData.productId)
    : null;

  return (
    <>
      <Header />
      <main className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <div className="bg-blue-600 text-white py-12 sm:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl font-bold mb-4">Bulk Orders</h1>
            <p className="text-blue-100 text-lg">
              Get special pricing for volume purchases. Contact us for custom quotes and enterprise solutions.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Form */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h2 className="text-2xl font-bold mb-6">Bulk Inquiry Form</h2>

                {submitted && (
                  <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-green-600 shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-bold text-green-900">Thank you!</h3>
                      <p className="text-green-800 text-sm">
                        We&apos;ve received your bulk inquiry. Our team will contact you within 24 hours with a custom quote.
                      </p>
                    </div>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Contact Information */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                          placeholder="John Doe"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                          placeholder="john@example.com"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Company Information */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Company Information</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Company Name *
                        </label>
                        <input
                          type="text"
                          name="company"
                          value={formData.company}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                          placeholder="Your Company Ltd."
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Phone Number *
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                          placeholder="+1 (555) 000-0000"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Product Selection */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Product Details</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Select Product *
                        </label>
                        <select
                          name="productId"
                          value={formData.productId}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                        >
                          <option value="">Choose a product...</option>
                          {products.filter(p => p.bulkPricingEnabled).map(product => (
                            <option key={product.id} value={product.id}>
                              {product.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Quantity *
                        </label>
                        <input
                          type="number"
                          name="quantity"
                          value={formData.quantity}
                          onChange={handleChange}
                          required
                          min="1"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                          placeholder="e.g., 25"
                        />
                      </div>
                    </div>

                    {/* Pricing Information */}
                    {selectedProduct && selectedProduct.bulkPrices && (
                      <div className="mt-4 bg-blue-50 p-4 rounded-lg border border-blue-200">
                        <p className="text-sm font-semibold text-blue-900 mb-3">Available bulk pricing:</p>
                        <div className="space-y-2">
                          {selectedProduct.bulkPrices.map((pricing, idx) => {
                            const discountedPrice = (selectedProduct.price * (1 - pricing.discountPercentage / 100)).toFixed(2);
                            return (
                              <p key={idx} className="text-sm text-blue-800">
                                {pricing.quantity}+ units: <span className="font-semibold">${discountedPrice}</span> each ({pricing.discountPercentage}% off)
                              </p>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Additional Information
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={5}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                      placeholder="Tell us about your project, timeline, and any special requirements..."
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-bold hover:bg-blue-700 transition disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {loading ? 'Submitting...' : 'Submit Bulk Inquiry'}
                  </button>
                </form>
              </div>
            </div>

            {/* Information Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-lg shadow-lg p-8 h-fit sticky top-24">
                <h3 className="text-xl font-bold mb-6">Why Choose Our Bulk Program?</h3>

                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="text-blue-600 text-2xl">💰</div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Volume Discounts</h4>
                      <p className="text-sm text-gray-600">
                        Save up to 40% with bulk pricing tiers starting from just 5 units.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="text-blue-600 text-2xl">🚀</div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Fast Processing</h4>
                      <p className="text-sm text-gray-600">
                        Quick order processing and immediate access to all products.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="text-blue-600 text-2xl">🤝</div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Dedicated Support</h4>
                      <p className="text-sm text-gray-600">
                        Get a dedicated account manager for orders over 50 units.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="text-blue-600 text-2xl">📋</div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Custom Quotes</h4>
                      <p className="text-sm text-gray-600">
                        Flexible payment terms and custom licensing options available.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="mt-8 pt-8 border-t border-gray-200 space-y-3">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-xs text-gray-600">Email</p>
                      <p className="text-sm font-semibold">bulk@jokepan.com</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-xs text-gray-600">Phone</p>
                      <p className="text-sm font-semibold">+1 (555) 123-4567</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
