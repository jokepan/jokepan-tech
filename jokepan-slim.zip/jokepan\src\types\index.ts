// Product Types
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  downloadUrl?: string;
  fileSize?: string;
  rating: number;
  reviews: number;
  isNew?: boolean;
  bulkPricingEnabled?: boolean;
  bulkPrices?: BulkPrice[];
}

export interface BulkPrice {
  quantity: number;
  discountPercentage: number;
}

// Bulk Buyer Contact Types
export interface BulkBuyerInquiry {
  id: string;
  name: string;
  email: string;
  company: string;
  phone: string;
  productId: string;
  quantity: number;
  message: string;
  createdAt: Date;
  status: 'new' | 'contacted' | 'negotiating' | 'completed';
}

// User Types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'buyer' | 'seller' | 'admin';
  company?: string;
  createdAt: Date;
}
