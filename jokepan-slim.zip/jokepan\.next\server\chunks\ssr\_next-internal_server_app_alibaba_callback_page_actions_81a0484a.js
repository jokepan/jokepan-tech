module.exports=[19927,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_alibaba_callback_page_actions_81a0484a.js.map