module.exports=[90349,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_wholesale_page_actions_6b8fd98c.js.map