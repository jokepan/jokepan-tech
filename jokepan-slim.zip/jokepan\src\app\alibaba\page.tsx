'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { generateAlibabaAuthUrl } from '@/lib/alibaba';
import { LogIn, CheckCircle, Zap } from 'lucide-react';
import Link from 'next/link';

export default function AlibabaPage() {
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnectAlibaba = async () => {
    setIsConnecting(true);
    try {
      const authUrl = generateAlibabaAuthUrl();
      // Redirect to Alibaba OAuth
      window.location.href = authUrl;
    } catch (error) {
      console.error('Error connecting to Alibaba:', error);
      setIsConnecting(false);
    }
  };

  return (
    <>
      <Header />
      <main className="min-h-screen" style={{ backgroundColor: '#FFFFFF' }}>
        {/* Hero Section */}
        <section style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }} className="text-white py-16 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">Connect Your Alibaba Account</h1>
            <p className="text-lg text-white text-opacity-90 mb-8 max-w-2xl mx-auto">
              Link your Alibaba supplier account to import products, manage inventory, and sync orders directly on JokePan.
            </p>
          </div>
        </section>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Benefits */}
            <div>
              <h2 className="text-3xl font-bold mb-8" style={{ color: '#FF6B6B' }}>Why Connect Alibaba?</h2>
              
              <div className="space-y-6">
                {[
                  {
                    icon: '📦',
                    title: 'Import Products',
                    desc: 'Sync products directly from your Alibaba supplier account',
                  },
                  {
                    icon: '💰',
                    title: 'Bulk Pricing',
                    desc: 'Automatic MOQ and bulk pricing from your Alibaba listings',
                  },
                  {
                    icon: '📊',
                    title: 'Manage Inventory',
                    desc: 'Track stock and manage inventory across platforms',
                  },
                  {
                    icon: '🔗',
                    title: 'Order Sync',
                    desc: 'Automatically sync orders to your Alibaba dashboard',
                  },
                  {
                    icon: '⭐',
                    title: 'Supplier Ratings',
                    desc: 'Display your Alibaba ratings and reviews',
                  },
                  {
                    icon: '🌍',
                    title: 'Global Reach',
                    desc: 'Access international buyers through JokePan',
                  },
                ].map((benefit, idx) => (
                  <div key={idx} className="flex gap-4">
                    <div className="text-3xl">{benefit.icon}</div>
                    <div>
                      <h3 className="font-bold mb-1" style={{ color: '#1a1a1a' }}>{benefit.title}</h3>
                      <p className="text-sm text-gray-600">{benefit.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Connection Box */}
            <div>
              <div className="bg-white rounded-2xl shadow-xl p-8" style={{ borderTop: '4px solid #FF6B6B' }}>
                <h3 className="text-2xl font-bold mb-6" style={{ color: '#1a1a1a' }}>Connect Your Account</h3>

                <div className="space-y-6 mb-8">
                  {/* Step 1 */}
                  <div className="flex gap-4">
                    <div className="shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: '#FF6B6B' }}>
                      1
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Click Connect</h4>
                      <p className="text-sm text-gray-600">You&apos;ll be redirected to Alibaba to authorize access</p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex gap-4">
                    <div className="shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: '#4ECDC4' }}>
                      2
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Authorize Access</h4>
                      <p className="text-sm text-gray-600">Grant JokePan permission to access your account</p>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex gap-4">
                    <div className="shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: '#FFD93D' }}>
                      3
                    </div>
                    <div>
                      <h4 className="font-bold mb-1">Import & Manage</h4>
                      <p className="text-sm text-gray-600">Start importing products and managing your store</p>
                    </div>
                  </div>
                </div>

                {/* Connect Button */}
                <button
                  onClick={handleConnectAlibaba}
                  disabled={isConnecting}
                  style={{
                    background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)',
                  }}
                  className="w-full text-white py-4 px-6 rounded-lg font-bold text-lg hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <LogIn className="w-5 h-5" />
                  {isConnecting ? 'Connecting...' : 'Connect Alibaba Account'}
                </button>

                <p className="text-xs text-center text-gray-500 mt-4">
                  We secure your data with 256-bit encryption. Your API key is never shared.
                </p>
              </div>

              {/* Features List */}
              <div className="mt-8 space-y-3">
                {[
                  'OAuth 2.0 Secure Connection',
                  'Real-time Product Sync',
                  'Automatic MOQ Detection',
                  'Bulk Pricing Import',
                  'Order Management',
                ].map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5" style={{ color: '#FF6B6B' }} />
                    <span className="text-sm" style={{ color: '#1a1a1a' }}>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* FAQ Section */}
          <div className="mt-16 pt-16" style={{ borderTop: '2px solid #f0f0f0' }}>
            <h2 className="text-3xl font-bold mb-8 text-center" style={{ color: '#FF6B6B' }}>FAQ</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  q: 'Is it safe to connect my Alibaba account?',
                  a: 'Yes! We use OAuth 2.0 secure authentication. Your credentials are never stored on our servers.',
                },
                {
                  q: 'What data can JokePan access?',
                  a: 'Only product information, MOQ, pricing, and order data. We cannot modify listings or take payments.',
                },
                {
                  q: 'Can I disconnect my account?',
                  a: 'Yes, anytime. Just go to Settings and click "Disconnect Alibaba Account".',
                },
                {
                  q: 'Does this cost extra?',
                  a: 'No, connecting your Alibaba account is completely free!',
                },
                {
                  q: 'How often are products synced?',
                  a: 'Products are synced in real-time when you manually trigger sync or every 24 hours automatically.',
                },
                {
                  q: 'Can I modify prices on JokePan?',
                  a: 'Yes! You can set custom markup or discounts for each product independently.',
                },
              ].map((item, idx) => (
                <div key={idx} className="bg-white p-6 rounded-lg" style={{ borderLeft: '4px solid #FF6B6B' }}>
                  <h3 className="font-bold mb-3" style={{ color: '#FF6B6B' }}>{item.q}</h3>
                  <p className="text-sm text-gray-600">{item.a}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Info Box */}
          <div className="mt-12 bg-white border-l-4 p-6 rounded-lg" style={{ borderColor: '#FF6B6B', backgroundColor: '#f8f8f8' }}>
            <div className="flex gap-4">
              <Zap className="w-6 h-6 shrink-0" style={{ color: '#FF6B6B' }} />
              <div>
                <h3 className="font-bold mb-2" style={{ color: '#FF6B6B' }}>First time connecting?</h3>
                <p className="text-sm text-gray-700 mb-3">
                  You&apos;ll need an active Alibaba supplier account. If you don&apos;t have one, visit{' '}
                  <a href="https://www.alibaba.com" target="_blank" rel="noopener noreferrer" className="font-semibold" style={{ color: '#FF6B6B' }}>
                    alibaba.com
                  </a>
                  {' '}to register first.
                </p>
              </div>
            </div>
          </div>

          {/* Back Link */}
          <div className="mt-12 text-center">
            <Link href="/products" className="font-semibold" style={{ color: '#FF6B6B' }}>
              ← Back to Products
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
