module.exports=[37980,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_products_page_actions_f4bcb93a.js.map