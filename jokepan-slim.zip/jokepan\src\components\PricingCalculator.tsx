'use client';

import { useState, useMemo } from 'react';
import { EXCHANGE_RATES, MARKET_CONFIG, MarketType } from '@/config/markets';
import { DollarSign, TrendingUp } from 'lucide-react';

interface PricingCalculatorProps {
  basePrice: number;
  selectedMarket: MarketType;
}

export default function PricingCalculator({ basePrice, selectedMarket }: PricingCalculatorProps) {
  const [quantity, setQuantity] = useState(10);
  const marketConfig = MARKET_CONFIG[selectedMarket];
  const exchangeRate = EXCHANGE_RATES[marketConfig.currency];

  const calculations = useMemo(() => {
    const localPrice = basePrice * exchangeRate;
    const subtotal = localPrice * quantity;

    // Sample bulk discounts
    let discountPercent = 0;
    if (quantity >= 50) discountPercent = 30;
    else if (quantity >= 25) discountPercent = 20;
    else if (quantity >= 10) discountPercent = 10;

    const discountAmount = subtotal * (discountPercent / 100);
    const total = subtotal - discountAmount;

    return {
      localPrice: localPrice.toFixed(2),
      subtotal: subtotal.toFixed(2),
      discountPercent,
      discountAmount: discountAmount.toFixed(2),
      total: total.toFixed(2),
      pricePerUnit: (total / quantity).toFixed(2),
    };
  }, [basePrice, exchangeRate, quantity]);

  return (
    <div className="bg-white rounded-lg shadow-lg p-8">
      <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <DollarSign className="w-6 h-6 text-blue-600" />
        Regional Pricing Calculator
      </h2>

      {/* Input Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Base Price */}
        <div>
          <label className="block text-sm font-semibold mb-2">Base Price (USD)</label>
          <div className="relative">
            <span className="absolute left-3 top-3 text-gray-500">$</span>
            <input
              type="number"
              value={basePrice}
              readOnly
              className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg bg-gray-50"
            />
          </div>
        </div>

        {/* Market Currency Price */}
        <div>
          <label className="block text-sm font-semibold mb-2">
            Price in {marketConfig.currency}
          </label>
          <div className="relative">
            <span className="absolute left-3 top-3 text-gray-500">{marketConfig.currencySymbol}</span>
            <input
              type="text"
              value={calculations.localPrice}
              readOnly
              className="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg bg-gray-50"
            />
          </div>
        </div>

        {/* Exchange Rate */}
        <div>
          <label className="block text-sm font-semibold mb-2">Exchange Rate</label>
          <div className="relative">
            <input
              type="text"
              value={`1 USD = ${exchangeRate} ${marketConfig.currency}`}
              readOnly
              className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-sm"
            />
          </div>
        </div>
      </div>

      {/* Quantity Slider */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-3">
          <label className="block text-sm font-semibold">Order Quantity</label>
          <span className="text-2xl font-bold text-blue-600">{quantity} units</span>
        </div>
        <input
          type="range"
          min={marketConfig.minOrderQuantity}
          max={500}
          step={5}
          value={quantity}
          onChange={(e) => setQuantity(parseInt(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
        <div className="flex justify-between text-xs text-gray-600 mt-2">
          <span>{marketConfig.minOrderQuantity}</span>
          <span>500+</span>
        </div>
      </div>

      {/* Pricing Breakdown */}
      <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg mb-8">
        <h3 className="text-lg font-bold mb-6">Pricing Breakdown</h3>

        <div className="space-y-4">
          {/* Subtotal */}
          <div className="flex justify-between items-center pb-4 border-b border-blue-200">
            <span className="text-gray-700">
              {quantity} units × {marketConfig.currencySymbol}{calculations.localPrice}
            </span>
            <span className="font-semibold">
              {marketConfig.currencySymbol}{calculations.subtotal}
            </span>
          </div>

          {/* Discount */}
          {calculations.discountPercent > 0 && (
            <div className="flex justify-between items-center pb-4 border-b border-blue-200">
              <span className="text-green-700 font-semibold">
                Bulk Discount ({calculations.discountPercent}%)
              </span>
              <span className="text-green-700 font-semibold">
                -{marketConfig.currencySymbol}{calculations.discountAmount}
              </span>
            </div>
          )}

          {/* Total */}
          <div className="flex justify-between items-center pt-4">
            <span className="text-lg font-bold">Total Price</span>
            <span className="text-3xl font-bold text-blue-600">
              {marketConfig.currencySymbol}{calculations.total}
            </span>
          </div>

          {/* Per Unit */}
          <div className="flex justify-between items-center text-sm text-gray-600">
            <span>Price per unit</span>
            <span className="font-semibold">
              {marketConfig.currencySymbol}{calculations.pricePerUnit}
            </span>
          </div>
        </div>
      </div>

      {/* Bulk Pricing Tiers */}
      <div>
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-green-600" />
          Bulk Pricing Tiers
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          {[
            { qty: 10, discount: 10 },
            { qty: 25, discount: 20 },
            { qty: 50, discount: 30 },
            { qty: 100, discount: 40 },
          ].map((tier, idx) => {
            const tierPrice = basePrice * exchangeRate * (1 - tier.discount / 100);
            return (
              <div
                key={idx}
                className={`p-4 rounded-lg border-2 transition cursor-pointer ${
                  quantity >= tier.qty
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-200 bg-gray-50'
                }`}
              >
                <p className="text-xs text-gray-600 font-semibold uppercase">
                  {tier.qty}+ units
                </p>
                <p className="text-xl font-bold text-gray-900 mt-1">
                  {tier.discount}% OFF
                </p>
                <p className="text-sm text-gray-700 mt-2">
                  {marketConfig.currencySymbol}{tierPrice.toFixed(2)}/unit
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
