// Alibaba Integration Module
export interface AlibabaAccount {
  id: string;
  userId: string;
  alibabaId: string;
  alibabaName: string;
  accessToken: string;
  refreshToken: string;
  isVerified: boolean;
  connectedAt: Date;
  lastSyncedAt?: Date;
}

export interface AlibabaProduct {
  id: string;
  alibabaProductId: string;
  title: string;
  category: string;
  description: string;
  minOrderQuantity: number;
  price: number;
  currency: string;
  images: string[];
  rating: number;
  reviews: number;
  supplier: {
    id: string;
    name: string;
    rating: number;
    responseRate: number;
  };
}

export interface AlibabaOAuthConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  scope: string[];
  apiBaseUrl: string;
}

// Placeholder Alibaba OAuth configuration
export const alibabaOAuthConfig: AlibabaOAuthConfig = {
  clientId: process.env.NEXT_PUBLIC_ALIBABA_CLIENT_ID || 'default_client_id',
  clientSecret: process.env.ALIBABA_CLIENT_SECRET || 'default_secret',
  redirectUri: process.env.NEXT_PUBLIC_ALIBABA_REDIRECT_URI || 'http://localhost:3000/alibaba/callback',
  scope: ['user.profile', 'product.read', 'order.read'],
  apiBaseUrl: 'https://api.alibaba.com/v1',
};

/**
 * Generate Alibaba OAuth login URL
 */
export function generateAlibabaAuthUrl(): string {
  const params = new URLSearchParams({
    client_id: alibabaOAuthConfig.clientId,
    redirect_uri: alibabaOAuthConfig.redirectUri,
    scope: alibabaOAuthConfig.scope.join(','),
    response_type: 'code',
    state: generateRandomState(),
  });

  return `https://auth.alibaba.com/oauth2/authorize?${params.toString()}`;
}

/**
 * Generate random state parameter for OAuth security
 */
function generateRandomState(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

/**
 * Exchange auth code for access token
 */
export async function exchangeAlibabaCode(code: string, _state: string): Promise<AlibabaAccount | null> {
  try {
    const response = await fetch(`${alibabaOAuthConfig.apiBaseUrl}/oauth/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        grant_type: 'authorization_code',
        code,
        client_id: alibabaOAuthConfig.clientId,
        client_secret: alibabaOAuthConfig.clientSecret,
        redirect_uri: alibabaOAuthConfig.redirectUri,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to exchange code for token');
    }

    const data = await response.json();

    return {
      id: `alibaba_${Date.now()}`,
      userId: '', // Will be set by the calling function
      alibabaId: data.user_id,
      alibabaName: data.user_name,
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      isVerified: true,
      connectedAt: new Date(),
    };
  } catch (error) {
    console.error('Error exchanging Alibaba code:', error);
    return null;
  }
}

/**
 * Fetch products from connected Alibaba account
 */
export async function fetchAlibabaProducts(
  accessToken: string,
  category?: string,
  page: number = 1,
  limit: number = 20
): Promise<AlibabaProduct[]> {
  try {
    const params = new URLSearchParams({
      access_token: accessToken,
      page: page.toString(),
      limit: limit.toString(),
    });

    if (category) {
      params.append('category', category);
    }

    const response = await fetch(`${alibabaOAuthConfig.apiBaseUrl}/products?${params.toString()}`, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch Alibaba products');
    }

    const data = await response.json();
    return data.products || [];
  } catch (error) {
    console.error('Error fetching Alibaba products:', error);
    return [];
  }
}

/**
 * Sync products from Alibaba to local platform
 */
export async function syncAlibabaProducts(account: AlibabaAccount): Promise<AlibabaProduct[]> {
  try {
    const products = await fetchAlibabaProducts(account.accessToken);
    account.lastSyncedAt = new Date();
    return products;
  } catch (error) {
    console.error('Error syncing Alibaba products:', error);
    return [];
  }
}
