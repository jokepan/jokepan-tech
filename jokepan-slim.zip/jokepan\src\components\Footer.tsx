import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="text-white py-12" style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4">JokePan</h3>
            <p className="text-sm text-gray-100">
              Premium fashion, beauty, and home products for entrepreneurs and wholesalers worldwide.
            </p>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-white font-semibold mb-4">Products</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/products" className="text-gray-300 hover:text-white transition">All Products</Link></li>
              <li><Link href="/products?category=Fashion" className="text-gray-300 hover:text-white transition">Fashion</Link></li>
              <li><Link href="/products?category=Beauty" className="text-gray-300 hover:text-white transition">Beauty</Link></li>
              <li><Link href="/products?category=Home" className="text-gray-300 hover:text-white transition">Home</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-white font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/about" className="text-gray-300 hover:text-white transition">About</Link></li>
              <li><Link href="/alibaba" className="text-gray-300 hover:text-white transition">Connect Alibaba</Link></li>
              <li><Link href="/bulk-inquiry" className="text-gray-300 hover:text-white transition">Bulk Orders</Link></li>
              <li><Link href="/contact" className="text-gray-300 hover:text-white transition">Contact</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-white font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/privacy" className="text-gray-300 hover:text-white transition">Privacy Policy</Link></li>
              <li><Link href="/terms" className="text-gray-300 hover:text-white transition">Terms of Service</Link></li>
              <li><Link href="/licenses" className="text-gray-300 hover:text-white transition">Licenses</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-600 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-100">
              © 2025 JokePan. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-300 hover:text-white transition">Twitter</a>
              <a href="#" className="text-gray-300 hover:text-white transition">Instagram</a>
              <a href="#" className="text-gray-300 hover:text-white transition">LinkedIn</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
