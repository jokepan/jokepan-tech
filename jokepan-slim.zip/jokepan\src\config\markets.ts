// Market and region configurations
export type MarketType = 'alibaba' | 'dubai' | 'africa' | 'global';
export type AfricanCountry = 'NG' | 'ZA' | 'KE' | 'ET' | 'GH' | 'UG' | 'TZ' | 'RW';

export interface Market {
  id: MarketType;
  name: string;
  region: string;
  currency: string;
  currencySymbol: string;
  defaultLanguage: string;
  minOrderQuantity: number;
  features: string[];
  paymentMethods: string[];
  shippingRegions: string[];
}

export interface RegionalPricing {
  basePrice: number;
  market: MarketType;
  currency: string;
  exchangeRate: number;
  localPrice: number;
  minOrderQuantity: number;
  bulkTiers: BulkTier[];
}

export interface BulkTier {
  quantity: number;
  discountPercentage: number;
  pricePerUnit: number;
}

export interface SupplierProfile {
  id: string;
  name: string;
  company: string;
  markets: MarketType[];
  rating: number;
  reviewCount: number;
  responseTime: string; // e.g., "Within 2 hours"
  certifications: string[];
  minOrderValue: number;
  shipsTo: string[];
  yearsInBusiness: number;
}

export interface WholesaleInquiry {
  id: string;
  supplierId: string;
  buyerId: string;
  productId: string;
  quantity: number;
  market: MarketType;
  requiredDeliveryDate?: Date;
  specialRequirements?: string;
  status: 'pending' | 'quoted' | 'negotiating' | 'confirmed' | 'rejected';
  createdAt: Date;
  updatedAt: Date;
}

export interface ExportDocument {
  id: string;
  type: 'invoice' | 'packing_list' | 'certificate_of_origin' | 'bill_of_lading';
  market: MarketType;
  orderId: string;
  generatedAt: Date;
  expiresAt?: Date;
  url: string;
}

export interface AfarAMarketplaceStats {
  totalBuyers: number;
  totalSuppliers: number;
  monthlyTransactions: number;
  totalGMV: number; // Gross Merchandise Volume
  currency: string;
}

export const MARKET_CONFIG: Record<MarketType, Market> = {
  alibaba: {
    id: 'alibaba',
    name: 'Alibaba Wholesale',
    region: 'Asia-Pacific',
    currency: 'USD',
    currencySymbol: '$',
    defaultLanguage: 'en',
    minOrderQuantity: 50,
    features: [
      'Minimum Order Quantity (MOQ)',
      'Supplier Ratings & Reviews',
      'Trade Assurance Protection',
      'Inspection & QC Services',
      'Bulk Pricing',
      'Direct Supplier Messaging',
      'Sample Ordering',
    ],
    paymentMethods: ['PayPal', 'Credit Card', 'Bank Transfer', 'Letter of Credit'],
    shippingRegions: ['Worldwide'],
  },
  dubai: {
    id: 'dubai',
    name: 'Dubai Market',
    region: 'Middle East',
    currency: 'AED',
    currencySymbol: 'د.إ',
    defaultLanguage: 'ar',
    minOrderQuantity: 100,
    features: [
      'Export/Import Compliance',
      'Customs Documentation',
      'Local Logistics',
      'Trade Finance',
      'Halal Certification',
      'Regional Distribution',
      'Bonded Warehouse Services',
    ],
    paymentMethods: ['Bank Transfer', 'Letter of Credit', 'Cash', 'Regional Cards'],
    shippingRegions: ['UAE', 'Middle East', 'Africa', 'Asia'],
  },
  africa: {
    id: 'africa',
    name: 'African Marketplace',
    region: 'Africa',
    currency: 'ZAR',
    currencySymbol: 'R',
    defaultLanguage: 'en',
    minOrderQuantity: 25,
    features: [
      'Local Currency Pricing',
      'Mobile Money Integration',
      'Regional Warehousing',
      'Intra-Africa Shipping',
      'Payment Flexibility',
      'Local Supplier Networks',
      'Risk Mitigation Programs',
    ],
    paymentMethods: ['Mobile Money', 'Bank Transfer', 'Payment Plans', 'Cash on Delivery'],
    shippingRegions: [
      'Nigeria',
      'South Africa',
      'Kenya',
      'Ethiopia',
      'Ghana',
      'Uganda',
      'Tanzania',
      'Rwanda',
    ],
  },
  global: {
    id: 'global',
    name: 'Global Marketplace',
    region: 'Worldwide',
    currency: 'USD',
    currencySymbol: '$',
    defaultLanguage: 'en',
    minOrderQuantity: 10,
    features: [
      'Multi-Currency Support',
      'Worldwide Shipping',
      'Multi-Language Support',
      'Global Buyer Protection',
      'Currency Conversion',
      'International Payment Methods',
    ],
    paymentMethods: [
      'Credit Card',
      'PayPal',
      'Bank Transfer',
      'Cryptocurrency',
      'Local Payments',
    ],
    shippingRegions: ['Worldwide'],
  },
};

// Currency exchange rates (would be fetched from API in production)
export const EXCHANGE_RATES: Record<string, number> = {
  USD: 1.0,
  AED: 3.67, // UAE Dirham
  ZAR: 18.5, // South African Rand
  NGN: 1550, // Nigerian Naira
  KES: 130, // Kenyan Shilling
  GHS: 15.5, // Ghanaian Cedi
  ETB: 120, // Ethiopian Birr
  UGX: 3850, // Ugandan Shilling
  TZS: 2600, // Tanzanian Shilling
  RWF: 1300, // Rwandan Franc
};

export const AFRICAN_COUNTRIES: Record<AfricanCountry, string> = {
  NG: 'Nigeria',
  ZA: 'South Africa',
  KE: 'Kenya',
  ET: 'Ethiopia',
  GH: 'Ghana',
  UG: 'Uganda',
  TZ: 'Tanzania',
  RW: 'Rwanda',
};
