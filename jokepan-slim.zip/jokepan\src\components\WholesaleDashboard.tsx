'use client';

import { useState } from 'react';
import { SupplierProfile, MARKET_CONFIG, MarketType } from '@/config/markets';
import { Star, MessageCircle, Award, Globe, TrendingUp } from 'lucide-react';
import Link from 'next/link';

interface SupplierCardProps {
  supplier: SupplierProfile;
  market: MarketType;
}

function SupplierCard({ supplier, market }: SupplierCardProps) {
  const marketConfig = MARKET_CONFIG[market];

  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6">
        <h3 className="text-xl font-bold mb-2">{supplier.name}</h3>
        <p className="text-blue-100">{supplier.company}</p>
      </div>

      {/* Content */}
      <div className="p-6 space-y-4">
        {/* Rating */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex text-yellow-400">
              {Array(5).fill(0).map((_, i) => (
                <Star
                  key={i}
                  className="w-4 h-4"
                  fill={i < Math.floor(supplier.rating) ? 'currentColor' : 'none'}
                />
              ))}
            </div>
            <span className="text-sm font-semibold text-gray-700">
              {supplier.rating} ({supplier.reviewCount} reviews)
            </span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded">
          <div>
            <p className="text-xs text-gray-600">Response Time</p>
            <p className="font-bold text-gray-900">{supplier.responseTime}</p>
          </div>
          <div>
            <p className="text-xs text-gray-600">Min. Order</p>
            <p className="font-bold text-gray-900">{marketConfig.currencySymbol}{supplier.minOrderValue}</p>
          </div>
          <div>
            <p className="text-xs text-gray-600">In Business</p>
            <p className="font-bold text-gray-900">{supplier.yearsInBusiness} years</p>
          </div>
          <div>
            <p className="text-xs text-gray-600">Certifications</p>
            <p className="font-bold text-gray-900">{supplier.certifications.length}</p>
          </div>
        </div>

        {/* Markets */}
        <div>
          <p className="text-xs text-gray-600 mb-2">Active Markets</p>
          <div className="flex flex-wrap gap-1">
            {supplier.markets.map(mkt => (
              <span key={mkt} className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">
                {MARKET_CONFIG[mkt].name}
              </span>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div>
          <p className="text-xs text-gray-600 mb-2">Certifications</p>
          <div className="flex flex-wrap gap-1">
            {supplier.certifications.map((cert, idx) => (
              <span key={idx} className="flex items-center gap-1 text-xs bg-green-50 text-green-700 px-2 py-1 rounded">
                <Award className="w-3 h-3" />
                {cert}
              </span>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-4 border-t border-gray-200">
          <Link
            href={`/wholesale/inquiry?supplier=${supplier.id}&market=${market}`}
            className="flex-1 bg-blue-600 text-white py-2 px-3 rounded font-semibold hover:bg-blue-700 transition text-center text-sm"
          >
            Request Quote
          </Link>
          <button className="flex-1 border border-gray-300 text-gray-700 py-2 px-3 rounded font-semibold hover:border-blue-300 transition flex items-center justify-center gap-2 text-sm">
            <MessageCircle className="w-4 h-4" />
            Message
          </button>
        </div>
      </div>
    </div>
  );
}

interface WholesaleDashboardProps {
  market: MarketType;
}

export default function WholesaleDashboard({ market }: WholesaleDashboardProps) {
  const [sortBy, setSortBy] = useState<'rating' | 'price' | 'response'>('rating');

  // Mock supplier data
  const suppliers: SupplierProfile[] = [
    {
      id: 'sup-001',
      name: 'TechPro Manufacturing',
      company: 'TechPro Co., Ltd.',
      markets: ['alibaba', 'global'],
      rating: 4.8,
      reviewCount: 2150,
      responseTime: 'Within 2 hours',
      certifications: ['ISO 9001', 'CE Certified'],
      minOrderValue: 5000,
      shipsTo: ['USA', 'EU', 'Asia', 'Africa'],
      yearsInBusiness: 15,
    },
    {
      id: 'sup-002',
      name: 'Dubai Trade Solutions',
      company: 'Dubai Trade LLC',
      markets: ['dubai', 'africa'],
      rating: 4.7,
      reviewCount: 1890,
      responseTime: 'Within 4 hours',
      certifications: ['ISO 9001', 'Halal Certified'],
      minOrderValue: 8000,
      shipsTo: ['Middle East', 'Africa', 'Asia'],
      yearsInBusiness: 12,
    },
    {
      id: 'sup-003',
      name: 'African Export Hub',
      company: 'African Trade Partners',
      markets: ['africa', 'global'],
      rating: 4.6,
      reviewCount: 856,
      responseTime: 'Within 6 hours',
      certifications: ['Trade Verified', 'Payment Secured'],
      minOrderValue: 2000,
      shipsTo: ['Africa', 'Europe', 'Asia'],
      yearsInBusiness: 8,
    },
    {
      id: 'sup-004',
      name: 'Global Supply Chain',
      company: 'Global SC Inc.',
      markets: ['alibaba', 'dubai', 'africa', 'global'],
      rating: 4.9,
      reviewCount: 3420,
      responseTime: 'Within 1 hour',
      certifications: ['ISO 9001', 'ISO 14001', 'OHSAS 18001'],
      minOrderValue: 3000,
      shipsTo: ['Worldwide'],
      yearsInBusiness: 20,
    },
  ];

  const filteredSuppliers = suppliers
    .filter(s => s.markets.includes(market))
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'price') return a.minOrderValue - b.minOrderValue;
      return 0;
    });

  return (
    <div className="space-y-8">
      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 border border-blue-200 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Suppliers</p>
              <p className="text-3xl font-bold text-blue-600">2,450+</p>
            </div>
            <TrendingUp className="w-8 h-8 text-blue-600 opacity-20" />
          </div>
        </div>

        <div className="bg-green-50 border border-green-200 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg. Rating</p>
              <p className="text-3xl font-bold text-green-600">4.7/5.0</p>
            </div>
            <Star className="w-8 h-8 text-green-600 opacity-20" fill="currentColor" />
          </div>
        </div>

        <div className="bg-purple-50 border border-purple-200 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg. Response</p>
              <p className="text-3xl font-bold text-purple-600">3.2 hrs</p>
            </div>
            <MessageCircle className="w-8 h-8 text-purple-600 opacity-20" />
          </div>
        </div>

        <div className="bg-orange-50 border border-orange-200 p-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Min. Order Qty</p>
              <p className="text-3xl font-bold text-orange-600">25+</p>
            </div>
            <Globe className="w-8 h-8 text-orange-600 opacity-20" />
          </div>
        </div>
      </div>

      {/* Sort Options */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Verified Suppliers</h2>
        <div className="flex gap-2">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'rating' | 'price' | 'response')}
            className="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="rating">Sort by Rating</option>
            <option value="price">Sort by Min. Order</option>
            <option value="response">Sort by Response Time</option>
          </select>
        </div>
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {filteredSuppliers.map(supplier => (
          <SupplierCard key={supplier.id} supplier={supplier} market={market} />
        ))}
      </div>

      {/* Load More */}
      <div className="text-center">
        <button className="bg-gray-100 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:bg-gray-200 transition">
          Load More Suppliers
        </button>
      </div>
    </div>
  );
}
