globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2139e000f4b5d584.js",
    "static/chunks/4ca6f35754fbe0d1.js",
    "static/chunks/06525dfb60487280.js",
    "static/chunks/a92b6a2da18471af.js",
    "static/chunks/turbopack-dfc0ca3902d795f6.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];