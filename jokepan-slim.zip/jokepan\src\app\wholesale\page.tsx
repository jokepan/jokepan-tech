'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Package } from 'lucide-react';

export default function WholesalePage() {

  return (
    <>
      <Header />
      <main className="min-h-screen" style={{ backgroundColor: '#FFFFFF' }}>
        {/* Hero Section */}
        <div style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }} className="text-white py-16 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">B2B Wholesale Marketplace</h1>
            <p className="text-xl text-white/90 max-w-3xl">
              Connect with verified suppliers for bulk orders. Access wholesale pricing, flexible payment terms, and sourcing support for Fashion, Beauty, and Home products.
            </p>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="bg-white border-b border-gray-200 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <Package className="w-10 h-10 text-blue-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-gray-900">5000+</p>
                <p className="text-gray-600">Suppliers Verified</p>
              </div>
              <div className="text-center">
                <Package className="w-10 h-10 text-blue-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-gray-900">150+</p>
                <p className="text-gray-600">Countries Covered</p>
              </div>
              <div className="text-center">
                <Package className="w-10 h-10 text-blue-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-gray-900">$500M+</p>
                <p className="text-gray-600">Annual Trade Volume</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          {/* Bulk Pricing Section */}
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-16">
            <h2 className="text-3xl font-bold mb-8 text-center" style={{ color: '#FF6B6B' }}>Wholesale Pricing Tiers</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { qty: '1-10', discount: 'Base Price', price: '$49.99' },
                { qty: '11-50', discount: '10% OFF', price: '$44.99' },
                { qty: '51-200', discount: '20% OFF', price: '$39.99' },
                { qty: '200+', discount: '30% OFF', price: '$34.99' },
              ].map((tier, idx) => (
                <div key={idx} className="border-2 rounded-lg p-6 text-center" style={{ borderColor: '#4ECDC4' }}>
                  <p className="text-sm text-gray-600 mb-2">Units</p>
                  <p className="text-2xl font-bold mb-2">{tier.qty}</p>
                  <p style={{ color: '#FF6B6B' }} className="font-bold text-lg">{tier.discount}</p>
                  <p className="text-xl font-bold text-gray-900 mt-3">{tier.price}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Key Features */}
          <h2 className="text-3xl font-bold mb-12 text-center" style={{ color: '#FF6B6B' }}>Why Choose Our Wholesale Platform</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {[
              { title: 'Verified Suppliers', desc: 'All suppliers are vetted and rated by our community' },
              { title: 'Bulk Discounts', desc: 'Tiered pricing structure for maximum savings' },
              { title: 'Flexible Payment', desc: 'Multiple payment methods and terms available' },
              { title: 'Fast Support', desc: 'Dedicated B2B support team for bulk orders' },
              { title: 'Quality Assurance', desc: 'Inspection and certification services included' },
              { title: 'Secure Trading', desc: 'Trade protection and dispute resolution' },
            ].map((feature, idx) => (
              <div key={idx} className="bg-white rounded-lg p-6 shadow hover:shadow-lg transition">
                <div className="flex gap-4">
                  <div style={{ color: '#4ECDC4' }}>
                    <Package className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
                    <p className="text-gray-600">{feature.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Market-Specific Info */}
          <div className="mt-20 pt-20 border-t-2" style={{ borderColor: '#f0f0f0' }}>
            <h2 className="text-3xl font-bold mb-12 text-center" style={{ color: '#FF6B6B' }}>Product Categories</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Fashion */}
              <div className="bg-white p-8 rounded-lg shadow hover:shadow-lg transition">
                <h3 className="text-2xl font-bold mb-6" style={{ color: '#FF6B6B' }}>Fashion</h3>
                <ul className="space-y-3">
                  {[
                    'Designer Templates',
                    'Bulk Clothing',
                    'Accessories',
                    'Seasonal Collections',
                    'Custom Branding',
                    'Quick Turnaround',
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <span style={{ color: '#FF6B6B' }} className="font-bold">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Beauty */}
              <div className="bg-white p-8 rounded-lg shadow hover:shadow-lg transition">
                <h3 className="text-2xl font-bold mb-6" style={{ color: '#4ECDC4' }}>Beauty</h3>
                <ul className="space-y-3">
                  {[
                    'Skincare Products',
                    'Makeup Tools',
                    'Cosmetics Kits',
                    'Natural Ingredients',
                    'Certification Available',
                    'Private Labeling',
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <span style={{ color: '#FF6B6B' }} className="font-bold">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Home */}
              <div className="bg-white p-8 rounded-lg shadow hover:shadow-lg transition">
                <h3 className="text-2xl font-bold mb-6" style={{ color: '#FFD93D' }}>Home & Décor</h3>
                <ul className="space-y-3">
                  {[
                    'Interior Design Items',
                    'Decor Collections',
                    'Home Furnishings',
                    'Bulk Orders',
                    'Customization',
                    'Wholesale Rates',
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <span style={{ color: '#FF6B6B' }} className="font-bold">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* How It Works */}
          <div className="mt-20 pt-20 border-t-2" style={{ borderColor: '#f0f0f0' }}>
            <h2 className="text-3xl font-bold mb-12 text-center" style={{ color: '#FF6B6B' }}>B2B Ordering Process</h2>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                {
                  step: '1',
                  title: 'Browse Products',
                  description: 'Explore our catalog of Fashion, Beauty, and Home products',
                },
                {
                  step: '2',
                  title: 'Request Quote',
                  description: 'Submit your bulk order requirements and get instant pricing',
                },
                {
                  step: '3',
                  title: 'Negotiate Terms',
                  description: 'Discuss payment terms, delivery, and customization options',
                },
                {
                  step: '4',
                  title: 'Place Order',
                  description: 'Confirm order and receive with full protection guarantee',
                },
              ].map((item, idx) => (
                <div key={idx} className="text-center">
                  <div style={{ backgroundColor: '#FF6B6B' }} className="w-16 h-16 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                    {item.step}
                  </div>
                  <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }} className="mt-20 text-white rounded-2xl p-12 text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Source Wholesale?</h2>
            <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto">
              Get bulk pricing on Fashion, Beauty, and Home products with flexible payment terms and fast support
            </p>
            <button style={{ backgroundColor: 'white', color: '#d4a5a5' }} className="px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition">
              Start Shopping Wholesale
            </button>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
