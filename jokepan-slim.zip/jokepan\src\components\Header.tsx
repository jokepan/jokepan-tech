'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ShoppingCart, Menu, X } from 'lucide-react';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50" style={{ backgroundColor: '#FFFFFF', borderBottom: '3px solid #FF6B6B' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #FFD93D 100%)' }}>
              <span className="text-white font-bold text-lg">🎭</span>
            </div>
            <span className="text-xl font-bold hidden sm:inline" style={{ color: '#FF6B6B' }}>JokePan</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="transition" style={{ color: '#1a1a1a' }}>Home</Link>
            <Link href="/products" className="transition" style={{ color: '#1a1a1a' }}>Products</Link>
            <Link href="/alibaba" className="transition font-semibold" style={{ color: '#FF6B6B' }}>Connect Alibaba</Link>
            <Link href="/bulk-inquiry" className="transition" style={{ color: '#1a1a1a' }}>Bulk Orders</Link>
            <Link href="/about" className="transition" style={{ color: '#1a1a1a' }}>About</Link>
          </nav>

          {/* Right side icons */}
          <div className="flex items-center space-x-4">
            <Link href="/cart" className="relative">
              <ShoppingCart className="w-6 h-6" style={{ color: '#FF6B6B' }} />
              <span className="absolute -top-2 -right-2 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center" style={{ background: '#FF6B6B' }}>0</span>
            </Link>

            {/* Mobile menu button */}
            <button
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" style={{ color: '#FF6B6B' }} />
              ) : (
                <Menu className="w-6 h-6" style={{ color: '#FF6B6B' }} />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden pb-4 space-y-2">
            <Link href="/" className="block px-4 py-2 rounded" style={{ color: '#1a1a1a' }}>Home</Link>
            <Link href="/products" className="block px-4 py-2 rounded" style={{ color: '#1a1a1a' }}>Products</Link>
            <Link href="/alibaba" className="block px-4 py-2 rounded font-semibold" style={{ color: '#FF6B6B' }}>Connect Alibaba</Link>
            <Link href="/bulk-inquiry" className="block px-4 py-2 rounded" style={{ color: '#1a1a1a' }}>Bulk Orders</Link>
            <Link href="/about" className="block px-4 py-2 rounded" style={{ color: '#1a1a1a' }}>About</Link>
          </nav>
        )}
      </div>
    </header>
  );
}
