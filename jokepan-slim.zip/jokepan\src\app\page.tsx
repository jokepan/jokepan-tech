import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import Link from 'next/link';
import { ArrowRight, CheckCircle, Users, Zap } from 'lucide-react';
import { products } from '@/data/products';

export default function Home() {
  const featuredProducts = products.slice(0, 6);

  return (
    <>
      <Header />
      <main className="min-h-screen" style={{ backgroundColor: '#FFFFFF' }}>
        {/* Hero Section */}
        <section style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }} className="text-white py-20 sm:py-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
                  Luxury Fashion, Beauty & Home Collections
                </h1>
                <p className="text-lg text-white text-opacity-90 mb-8">
                  Discover premium digital products for fashion designers, beauty entrepreneurs, and home decor professionals. Connect with global wholesale buyers.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link
                    href="/products"
                    className="text-white px-8 py-3 rounded-lg font-bold hover:shadow-lg transition flex items-center justify-center gap-2"
                    style={{ backgroundColor: 'rgba(255,255,255,0.2)', border: '2px solid white' }}
                  >
                    Browse Products <ArrowRight className="w-5 h-5" />
                  </Link>
                  <Link
                    href="/alibaba"
                    className="text-white px-8 py-3 rounded-lg font-bold hover:shadow-lg transition flex items-center justify-center gap-2"
                    style={{ backgroundColor: 'rgba(255,255,255,0.3)' }}
                  >
                    Connect Alibaba <Users className="w-5 h-5" />
                  </Link>
                </div>
              </div>

              {/* Hero Image Placeholder */}
              <div className="hidden md:flex items-center justify-center">
                <div className="rounded-2xl p-8" style={{ background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(10px)' }}>
                  <div className="aspect-square rounded-lg flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.05)' }}>
                    <span className="text-white text-opacity-50 text-xl">✨ Gleamy & Luxurious ✨</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Trust Section */}
        <section style={{ backgroundColor: '#f8f8f8' }} className="py-12 sm:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold mb-2" style={{ color: '#FF6B6B' }}>8000+</div>
                <p style={{ color: '#1a1a1a' }}>Happy Customers</p>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2" style={{ color: '#FF6B6B' }}>300+</div>
                <p style={{ color: '#1a1a1a' }}>Premium Products</p>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2" style={{ color: '#FF6B6B' }}>$5M+</div>
                <p style={{ color: '#1a1a1a' }}>Total Sales</p>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-16 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12" style={{ color: '#FF6B6B' }}>Why Choose JokePan?</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: <CheckCircle className="w-8 h-8" style={{ color: '#4ECDC4' }} />,
                  title: 'Luxury Curation',
                  description: 'Handpicked fashion, beauty & home products for discerning entrepreneurs.',
                },
                {
                  icon: <Zap className="w-8 h-8" style={{ color: '#4ECDC4' }} />,
                  title: 'Instant Access',
                  description: 'Get immediate access with one-click downloads and lifetime updates.',
                },
                {
                  icon: <Users className="w-8 h-8" style={{ color: '#4ECDC4' }} />,
                  title: 'Alibaba Connected',
                  description: 'Seamless integration with Alibaba suppliers and wholesale networks.',
                },
              ].map((feature, index) => (
                <div key={index} className="p-8 rounded-lg" style={{ backgroundColor: '#f8f8f8' }}>
                  <div className="mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-bold mb-3" style={{ color: '#FF6B6B' }}>{feature.title}</h3>
                  <p style={{ color: '#1a1a1a' }}>{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Products */}
        <section style={{ backgroundColor: '#f8f8f8' }} className="py-16 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center mb-12">
              <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: '#FF6B6B' }}>Featured Collections</h2>
              <Link
                href="/products"
                className="font-semibold hover:opacity-80 transition flex items-center gap-2"
                style={{ color: '#FF6B6B' }}
              >
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>

        {/* Alibaba Integration CTA */}
        <section style={{ background: 'linear-gradient(135deg, #4ECDC4 0%, #FFD93D 100%)' }} className="text-white py-16 sm:py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl sm:text-4xl font-bold mb-6">Connect to Alibaba & Wholesale Markets</h2>
            <p className="text-lg text-white text-opacity-90 mb-8">
              Link your Alibaba supplier account to import products, manage inventory, and reach global bulk buyers.
            </p>
            <Link
              href="/alibaba"
              className="inline-block text-white px-8 py-4 rounded-lg font-bold hover:shadow-lg transition"
              style={{ background: 'rgba(0,0,0,0.15)' }}
            >
              Connect Alibaba Account →
            </Link>
          </div>
        </section>

        {/* Categories Preview */}
        <section className="py-16 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl sm:text-4xl font-bold text-center mb-12" style={{ color: '#FF6B6B' }}>Browse by Category</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {['Fashion', 'Beauty', 'Home'].map((category) => (
                <Link
                  key={category}
                  href={`/products?category=${category}`}
                  className="p-6 rounded-lg hover:shadow-md transition text-center group"
                  style={{ backgroundColor: '#f8f8f8' }}
                >
                  <div className="text-3xl mb-3">
                    {category === 'Fashion' && '👗'}
                    {category === 'Beauty' && '💄'}
                    {category === 'Home' && '🏠'}
                  </div>
                  <h3 className="font-bold text-lg group-hover:opacity-80 transition" style={{ color: '#FF6B6B' }}>{category}</h3>
                  <p className="text-sm mt-2" style={{ color: '#1a1a1a' }}>
                    {products.filter(p => p.category === category).length} products
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
