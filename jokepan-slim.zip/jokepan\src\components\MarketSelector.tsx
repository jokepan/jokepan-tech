'use client';

import React from 'react';
import { MARKET_CONFIG, MarketType, Market } from '@/config/markets';
import { Globe, Zap, Shield, TrendingUp } from 'lucide-react';

interface MarketSelectorProps {
  selectedMarket: MarketType;
  onMarketChange: (market: MarketType) => void;
}

export default function MarketSelector({ selectedMarket, onMarketChange }: MarketSelectorProps) {
  const currentMarket = MARKET_CONFIG[selectedMarket];

  const marketIcons: Record<MarketType, React.ReactNode> = {
    alibaba: <TrendingUp className="w-6 h-6" />,
    dubai: <Zap className="w-6 h-6" />,
    africa: <Globe className="w-6 h-6" />,
    global: <Shield className="w-6 h-6" />,
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold mb-6">Select Your Market</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {Object.values(MARKET_CONFIG).map((market: Market) => (
          <button
            key={market.id}
            onClick={() => onMarketChange(market.id)}
            className={`p-6 rounded-lg border-2 transition ${
              selectedMarket === market.id
                ? 'border-blue-600 bg-blue-50'
                : 'border-gray-200 bg-white hover:border-blue-300'
            }`}
          >
            <div className={`text-3xl mb-3 ${selectedMarket === market.id ? 'text-blue-600' : 'text-gray-600'}`}>
              {marketIcons[market.id]}
            </div>
            <h3 className="font-bold text-lg mb-1">{market.name}</h3>
            <p className="text-sm text-gray-600">{market.region}</p>
            <p className="text-sm font-semibold mt-2">{market.currencySymbol}</p>
          </button>
        ))}
      </div>

      {/* Market Details */}
      <div className="bg-gray-50 p-8 rounded-lg">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column */}
          <div>
            <h3 className="text-xl font-bold mb-4">Market Information</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600">Minimum Order Quantity</p>
                <p className="text-2xl font-bold text-blue-600">{currentMarket.minOrderQuantity} units</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Primary Currency</p>
                <p className="text-lg font-semibold">{currentMarket.currency} ({currentMarket.currencySymbol})</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Default Language</p>
                <p className="text-lg font-semibold capitalize">{currentMarket.defaultLanguage}</p>
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div>
            <h3 className="text-xl font-bold mb-4">Key Features</h3>
            <ul className="space-y-2">
              {currentMarket.features.map((feature: string, idx: number) => (
                <li key={idx} className="flex items-start gap-2 text-sm">
                  <span className="text-green-600 font-bold mt-0.5">✓</span>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="mt-8 pt-8 border-t border-gray-300">
          <h3 className="text-lg font-bold mb-4">Accepted Payment Methods</h3>
          <div className="flex flex-wrap gap-2">
            {currentMarket.paymentMethods.map((method: string, idx: number) => (
              <span
                key={idx}
                className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-semibold"
              >
                {method}
              </span>
            ))}
          </div>
        </div>

        {/* Shipping Regions */}
        <div className="mt-6">
          <h3 className="text-lg font-bold mb-4">Shipping Regions</h3>
          <div className="flex flex-wrap gap-2">
            {currentMarket.shippingRegions.map((region: string, idx: number) => (
              <span key={idx} className="bg-gray-200 text-gray-800 px-4 py-2 rounded-full text-sm">
                {region}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
