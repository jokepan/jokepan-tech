'use client';

import { useState } from 'react';
import { useParams } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { products } from '@/data/products';
import { Star, Download, Share2, ShoppingCart, ChevronRight } from 'lucide-react';
import Link from 'next/link';

export default function ProductDetailPage() {
  const params = useParams();
  const productId = params.id as string;

  const product = products.find(p => p.id === productId);
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <>
        <Header />
        <main className="min-h-screen bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
            <h1 className="text-4xl font-bold mb-4">Product Not Found</h1>
            <p className="text-gray-600 mb-8">The product you&apos;re looking for doesn&apos;t exist.</p>
            <Link href="/products" className="text-blue-600 font-semibold">
              ← Back to Products
            </Link>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 3);

  return (
    <>
      <Header />
      <main className="min-h-screen bg-white">
        {/* Breadcrumb */}
        <div className="border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center space-x-2 text-sm">
              <Link href="/" className="text-blue-600 hover:text-blue-700">Home</Link>
              <ChevronRight className="w-4 h-4 text-gray-400" />
              <Link href="/products" className="text-blue-600 hover:text-blue-700">Products</Link>
              <ChevronRight className="w-4 h-4 text-gray-400" />
              <span className="text-gray-600">{product.name}</span>
            </div>
          </div>
        </div>

        {/* Product Detail */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Image */}
            <div className="bg-gray-100 rounded-lg overflow-hidden">
              <div className="w-full aspect-square bg-linear-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                <span className="text-gray-400 text-lg">Product Image</span>
              </div>
            </div>

            {/* Product Info */}
            <div className="flex flex-col">
              {/* Badge */}
              <div className="mb-4 inline-flex w-fit">
                <span className="bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-semibold">
                  {product.category}
                </span>
              </div>

              {/* Title */}
              <h1 className="text-4xl font-bold mb-4">{product.name}</h1>

              {/* Rating */}
              <div className="flex items-center mb-6">
                <div className="flex text-yellow-400">
                  {Array(5).fill(0).map((_, i) => (
                    <Star key={i} className="w-5 h-5" fill="currentColor" />
                  ))}
                </div>
                <span className="ml-3 text-gray-600">
                  {product.rating} out of 5 ({product.reviews} reviews)
                </span>
              </div>

              {/* Description */}
              <p className="text-lg text-gray-600 mb-8">{product.description}</p>

              {/* Price */}
              <div className="mb-8">
                <div className="text-4xl font-bold text-gray-900 mb-2">${product.price}</div>
                <p className="text-gray-600 text-sm">Lifetime access with one-time purchase</p>
              </div>

              {/* Bulk Pricing Info */}
              {product.bulkPricingEnabled && product.bulkPrices && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-8">
                  <h3 className="font-semibold text-green-900 mb-3">Bulk Pricing Available</h3>
                  <div className="space-y-1 text-sm text-green-800">
                    {product.bulkPrices.map((pricing, idx) => {
                      const discountedPrice = (product.price * (1 - pricing.discountPercentage / 100)).toFixed(2);
                      return (
                        <p key={idx}>
                          {pricing.quantity}+ units: <span className="font-semibold">${discountedPrice}</span> each
                        </p>
                      );
                    })}
                  </div>
                  <p className="text-xs text-green-700 mt-3">
                    Need more? <Link href="/bulk-inquiry" className="font-semibold underline">Contact us for custom quotes</Link>
                  </p>
                </div>
              )}

              {/* Purchase Section */}
              <div className="mb-8">
                <label className="block text-sm font-semibold mb-2">Quantity</label>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="border border-gray-300 rounded-lg px-4 py-2 hover:bg-gray-100"
                  >
                    −
                  </button>
                  <span className="text-lg font-semibold w-8 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="border border-gray-300 rounded-lg px-4 py-2 hover:bg-gray-100"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <button className="flex-1 bg-blue-600 text-white py-4 px-6 rounded-lg font-bold hover:bg-blue-700 transition flex items-center justify-center gap-2">
                  <ShoppingCart className="w-5 h-5" />
                  Add to Cart
                </button>
                <button className="flex-1 border-2 border-gray-300 text-gray-700 py-4 px-6 rounded-lg font-bold hover:border-gray-400 transition flex items-center justify-center gap-2">
                  <Download className="w-5 h-5" />
                  Direct Download
                </button>
                <button className="border-2 border-gray-300 text-gray-700 py-4 px-6 rounded-lg font-bold hover:border-gray-400 transition flex items-center justify-center">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>

              {/* Product Details */}
              <div className="border-t border-gray-200 pt-8">
                <h3 className="font-bold text-lg mb-4">Product Details</h3>
                <div className="space-y-3 text-sm text-gray-600">
                  {product.fileSize && (
                    <div className="flex justify-between">
                      <span>File Size:</span>
                      <span className="font-semibold text-gray-900">{product.fileSize}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Format:</span>
                    <span className="font-semibold text-gray-900">Digital Download</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Lifetime Access:</span>
                    <span className="font-semibold text-gray-900">Yes</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Support:</span>
                    <span className="font-semibold text-gray-900">Community</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* What's Included */}
          <div className="mt-16 pt-16 border-t border-gray-200">
            <h2 className="text-3xl font-bold mb-8">What&apos;s Included</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { icon: '📦', title: 'Source Files', desc: 'Access to all source files and code' },
                { icon: '📚', title: 'Documentation', desc: 'Comprehensive documentation and guides' },
                { icon: '🔄', title: 'Updates', desc: 'Lifetime updates and improvements' },
              ].map((item, idx) => (
                <div key={idx} className="text-center">
                  <div className="text-4xl mb-3">{item.icon}</div>
                  <h3 className="font-bold text-lg mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Reviews Section */}
          <div className="mt-16 pt-16 border-t border-gray-200">
            <h2 className="text-3xl font-bold mb-8">Customer Reviews</h2>
            <div className="space-y-6">
              {[
                {
                  name: 'Sarah Anderson',
                  role: 'Product Designer',
                  rating: 5,
                  text: 'Absolutely love this product! The quality is outstanding and the documentation is clear.',
                },
                {
                  name: 'Mike Johnson',
                  role: 'Full Stack Developer',
                  rating: 5,
                  text: 'Great value for money. Saved me so much time integrating this into my project.',
                },
                {
                  name: 'Emma White',
                  role: 'Startup Founder',
                  rating: 4,
                  text: 'Very useful product with good support. Would appreciate more customization options.',
                },
              ].map((review, idx) => (
                <div key={idx} className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold text-gray-900">{review.name}</h3>
                      <p className="text-sm text-gray-600">{review.role}</p>
                    </div>
                    <div className="flex text-yellow-400">
                      {Array(review.rating).fill(0).map((_, i) => (
                        <Star key={i} className="w-4 h-4" fill="currentColor" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-700">{review.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="mt-16 pt-16 border-t border-gray-200">
              <h2 className="text-3xl font-bold mb-8">Related Products</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {relatedProducts.map(prod => (
                  <Link
                    key={prod.id}
                    href={`/products/${prod.id}`}
                    className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition"
                  >
                    <div className="bg-linear-to-br from-blue-100 to-purple-100 h-48 flex items-center justify-center">
                      <span className="text-gray-400">Product Image</span>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-900 mb-2">{prod.name}</h3>
                      <p className="text-2xl font-bold text-blue-600">${prod.price}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  );
}
