'use client';

import Link from 'next/link';
import { Star, ShoppingCart } from 'lucide-react';
import { Product } from '@/types';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition group overflow-hidden border-b-4" style={{ borderColor: '#4ECDC4' }}>
      {/* Image Container */}
      <div className="relative w-full h-48 overflow-hidden">
        <div className="w-full h-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%)' }}>
          <span className="text-gray-400 text-sm">Product Image</span>
        </div>
        {product.isNew && (
          <div className="absolute top-2 right-2 text-white px-3 py-1 rounded-full text-xs font-semibold" style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #FFD93D 100%)' }}>
            New
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col h-full">
        <div className="grow">
          <p className="text-xs font-semibold uppercase mb-1" style={{ color: '#FF6B6B' }}>{product.category}</p>
          <h3 className="text-lg font-bold mb-2" style={{ color: '#1a1a1a' }}>{product.name}</h3>
          <p className="text-sm mb-4" style={{ color: '#666' }}>{product.description}</p>

          {/* Rating */}
          <div className="flex items-center mb-4">
            <div className="flex" style={{ color: '#FFD93D' }}>
              {Array(5).fill(0).map((_, i) => (
                <Star key={i} className="w-4 h-4" fill="currentColor" />
              ))}
            </div>
            <span className="text-sm ml-2" style={{ color: '#666' }}>
              {product.rating} ({product.reviews})
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t pt-4" style={{ borderColor: '#f0f0f0' }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-2xl font-bold" style={{ color: '#FF6B6B' }}>${product.price}</span>
            <span className="text-xs" style={{ color: '#666' }}>{product.fileSize}</span>
          </div>

          {product.bulkPricingEnabled && (
            <p className="text-xs font-semibold mb-3" style={{ color: '#4ECDC4' }}>✓ Bulk pricing available</p>
          )}

          <div className="flex gap-2">
            <Link
              href={`/products/${product.id}`}
              className="flex-1 text-white py-2 px-3 rounded font-semibold text-sm hover:shadow-md transition text-center"
              style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #FFD93D 100%)' }}
            >
              View Details
            </Link>
            <button className="py-2 px-3 rounded hover:shadow-md transition" style={{ backgroundColor: '#f0f0f0' }}>
              <ShoppingCart className="w-5 h-5" style={{ color: '#FF6B6B' }} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
