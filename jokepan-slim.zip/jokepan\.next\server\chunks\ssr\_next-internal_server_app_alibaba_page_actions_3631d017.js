module.exports=[39656,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_alibaba_page_actions_3631d017.js.map