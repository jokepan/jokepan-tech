'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { exchangeAlibabaCode } from '@/lib/alibaba';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { CheckCircle, AlertCircle, Loader } from 'lucide-react';

function CallbackContent() {
  const searchParams = useSearchParams();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const handleCallback = async () => {
      const code = searchParams.get('code');
      const state = searchParams.get('state');
      const error = searchParams.get('error');

      if (error) {
        setStatus('error');
        setMessage(`Alibaba authentication failed: ${error}`);
        return;
      }

      if (!code || !state) {
        setStatus('error');
        setMessage('Missing authorization code. Please try again.');
        return;
      }

      try {
        const account = await exchangeAlibabaCode(code, state);

        if (account) {
          // Store account info in localStorage for demo
          localStorage.setItem(
            'alibabaAccount',
            JSON.stringify({
              alibabaId: account.alibabaId,
              alibabaName: account.alibabaName,
              connectedAt: account.connectedAt,
            })
          );

          setStatus('success');
          setMessage('Your Alibaba account has been connected successfully!');
        } else {
          setStatus('error');
          setMessage('Failed to connect to Alibaba. Please try again.');
        }
      } catch (error) {
        setStatus('error');
        setMessage(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    };

    handleCallback();
  }, [searchParams]);

  return (
    <main className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#FFFFFF' }}>
      <div className="max-w-md w-full mx-auto px-4">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
          {status === 'loading' && (
            <>
              <Loader className="w-16 h-16 mx-auto mb-4 animate-spin" style={{ color: '#FF6B6B' }} />
              <h2 className="text-2xl font-bold mb-2" style={{ color: '#1a1a1a' }}>Connecting...</h2>
              <p className="text-gray-600">Please wait while we connect your Alibaba account.</p>
            </>
          )}

          {status === 'success' && (
            <>
              <div className="mb-4">
                <CheckCircle className="w-16 h-16 mx-auto" style={{ color: '#4ECDC4' }} />
              </div>
              <h2 className="text-2xl font-bold mb-2" style={{ color: '#FF6B6B' }}>Success!</h2>
              <p className="text-gray-600 mb-6">{message}</p>
              <Link
                href="/alibaba/dashboard"
                style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }}
                className="inline-block text-white py-3 px-8 rounded-lg font-bold hover:shadow-lg transition"
              >
                Go to Dashboard
              </Link>
            </>
          )}

          {status === 'error' && (
            <>
              <div className="mb-4">
                <AlertCircle className="w-16 h-16 mx-auto" style={{ color: '#FF6B6B' }} />
              </div>
              <h2 className="text-2xl font-bold mb-2" style={{ color: '#FF6B6B' }}>Connection Failed</h2>
              <p className="text-gray-600 mb-6">{message}</p>
              <Link
                href="/alibaba"
                className="inline-block border-2 py-3 px-8 rounded-lg font-bold transition"
                style={{ borderColor: '#FF6B6B', color: '#FF6B6B' }}
              >
                Try Again
              </Link>
            </>
          )}
        </div>
      </div>
    </main>
  );
}

export default function AlibabaCallbackPage() {
  return (
    <>
      <Header />
      <Suspense fallback={
        <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#FFFFFF' }}>
          <div className="max-w-md w-full mx-auto px-4">
            <div className="bg-white rounded-2xl shadow-xl p-8 text-center">
              <Loader className="w-16 h-16 mx-auto mb-4 animate-spin" style={{ color: '#FF6B6B' }} />
              <h2 className="text-2xl font-bold mb-2" style={{ color: '#1a1a1a' }}>Connecting...</h2>
              <p className="text-gray-600">Please wait while we connect your Alibaba account.</p>
            </div>
          </div>
        </div>
      }>
        <CallbackContent />
      </Suspense>
      <Footer />
    </>
  );
}
