'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { RefreshCw, LogOut, Plus, Settings } from 'lucide-react';

interface ConnectedAccount {
  alibabaId: string;
  alibabaName: string;
  connectedAt: string;
}

export default function AlibabaDashboardPage() {
  const [account, setAccount] = useState<ConnectedAccount | null>(() => {
    // Load connected account from localStorage  
    if (typeof window === 'undefined') return null;
    const accountData = localStorage.getItem('alibabaAccount');
    return accountData ? JSON.parse(accountData) : null;
  });
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState('');

  const handleSync = async () => {
    setIsSyncing(true);
    setSyncStatus('Syncing products...');
    
    // Simulate sync
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setSyncStatus('Products synced successfully! ✓');
    setIsSyncing(false);

    setTimeout(() => setSyncStatus(''), 3000);
  };

  const handleDisconnect = () => {
    if (confirm('Are you sure you want to disconnect your Alibaba account?')) {
      localStorage.removeItem('alibabaAccount');
      setAccount(null);
    }
  };

  if (!account) {
    return (
      <>
        <Header />
        <main className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#FFFFFF' }}>
          <div className="max-w-md text-center">
            <h2 className="text-2xl font-bold mb-4" style={{ color: '#FF6B6B' }}>No Account Connected</h2>
            <p className="text-gray-600 mb-8">Connect your Alibaba account to manage products and orders.</p>
            <Link
              href="/alibaba"
              style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }}
              className="inline-block text-white py-3 px-8 rounded-lg font-bold hover:shadow-lg transition"
            >
              Connect Alibaba Account
            </Link>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      <main className="min-h-screen" style={{ backgroundColor: '#FFFFFF' }}>
        {/* Header */}
        <div style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }} className="text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl font-bold mb-2">Alibaba Supplier Dashboard</h1>
            <p className="text-white text-opacity-90">Manage your products and sync inventory</p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Account Info Card */}
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-2xl font-bold mb-2" style={{ color: '#FF6B6B' }}>Connected Account</h2>
                <p className="text-gray-600">
                  <strong>Alibaba ID:</strong> {account.alibabaId}
                </p>
                <p className="text-gray-600">
                  <strong>Account Name:</strong> {account.alibabaName}
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  Connected on {new Date(account.connectedAt).toLocaleDateString()}
                </p>
              </div>
              <button
                onClick={handleDisconnect}
                className="flex items-center gap-2 px-4 py-2 border-2 rounded-lg transition"
                style={{ borderColor: '#FF6B6B', color: '#FF6B6B' }}
              >
                <LogOut className="w-4 h-4" />
                Disconnect
              </button>
            </div>

            {/* Sync Status */}
            {syncStatus && (
              <div className="mt-4 p-4 rounded-lg" style={{ backgroundColor: '#f8f8f8', color: '#FF6B6B' }}>
                {syncStatus}
              </div>
            )}
          </div>

          {/* Actions Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Sync Products */}
            <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
              <RefreshCw className="w-12 h-12 mx-auto mb-4" style={{ color: '#FF6B6B' }} />
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1a1a1a' }}>Sync Products</h3>
              <p className="text-gray-600 mb-6">Import your latest products and pricing from Alibaba</p>
              <button
                onClick={handleSync}
                disabled={isSyncing}
                style={{
                  background: isSyncing ? '#ccc' : 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)',
                }}
                className="w-full text-white py-3 rounded-lg font-bold hover:shadow-lg transition disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                {isSyncing ? 'Syncing...' : 'Sync Now'}
              </button>
            </div>

            {/* Import New Product */}
            <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
              <Plus className="w-12 h-12 mx-auto mb-4" style={{ color: '#4ECDC4' }} />
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1a1a1a' }}>Import Product</h3>
              <p className="text-gray-600 mb-6">Manually import a specific product from Alibaba</p>
              <button
                style={{ background: 'linear-gradient(135deg, #4ECDC4 0%, #FFD93D 100%)' }}
                className="w-full text-white py-3 rounded-lg font-bold hover:shadow-lg transition flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Import Product
              </button>
            </div>

            {/* Settings */}
            <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
              <Settings className="w-12 h-12 mx-auto mb-4" style={{ color: '#FFD93D' }} />
              <h3 className="text-xl font-bold mb-3" style={{ color: '#1a1a1a' }}>Settings</h3>
              <p className="text-gray-600 mb-6">Configure sync preferences and pricing rules</p>
              <button
                style={{ background: 'linear-gradient(135deg, #FFD93D 0%, #FF6B6B 100%)' }}
                className="w-full text-white py-3 rounded-lg font-bold hover:shadow-lg transition flex items-center justify-center gap-2"
              >
                <Settings className="w-4 h-4" />
                Settings
              </button>
            </div>
          </div>

          {/* Products Section */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h3 className="text-2xl font-bold mb-6" style={{ color: '#FF6B6B' }}>Imported Products</h3>
            
            <div className="text-center py-12">
              <p className="text-gray-600 mb-4">No products imported yet</p>
              <p className="text-sm text-gray-500">Click &quot;Sync Products&quot; to import your Alibaba listings</p>
            </div>
          </div>

          {/* Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <div className="bg-white rounded-2xl shadow-lg p-6" style={{ borderLeft: '4px solid #FF6B6B' }}>
              <h4 className="font-bold mb-3" style={{ color: '#FF6B6B' }}>Auto Sync Settings</h4>
              <p className="text-sm text-gray-600 mb-4">
                Products are automatically synced every 24 hours. You can also manually trigger sync anytime.
              </p>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" defaultChecked className="w-4 h-4" style={{ accentColor: '#FF6B6B' }} />
                <span className="text-sm">Enable automatic daily sync</span>
              </label>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-6" style={{ borderLeft: '4px solid #4ECDC4' }}>
              <h4 className="font-bold mb-3" style={{ color: '#4ECDC4' }}>Pricing Rules</h4>
              <p className="text-sm text-gray-600 mb-4">
                Set markup percentage or custom pricing for products imported from Alibaba.
              </p>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Default Markup:</span>
                  <input type="number" defaultValue="30" className="w-16 border rounded px-2" placeholder="%" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
