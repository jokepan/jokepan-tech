module.exports=[86972,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bulk-inquiry_page_actions_f6e4d34b.js.map