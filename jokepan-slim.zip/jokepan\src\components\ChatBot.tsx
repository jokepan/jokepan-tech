'use client';

import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hi! 👋 Welcome to JokePan. I'm your wholesale assistant. How can I help you today?",
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();

    // Pricing inquiries
    if (message.includes('price') || message.includes('cost') || message.includes('bulk discount')) {
      return "Our wholesale pricing offers great discounts:\n\n• 1-10 units: Base Price ($49.99)\n• 11-50 units: 10% OFF ($44.99)\n• 51-200 units: 20% OFF ($39.99)\n• 200+ units: 30% OFF ($34.99)\n\nWould you like to know about a specific product?";
    }

    // Product categories
    if (message.includes('product') || message.includes('category') || message.includes('what do you sell')) {
      return "We offer premium wholesale products in three categories:\n\n💄 **Beauty** - Skincare, makeup tools, cosmetics\n👗 **Fashion** - Designer templates, clothing, accessories\n🏠 **Home** - Interior design, décor, furnishings\n\nWhich category interests you?";
    }

    // Alibaba integration
    if (message.includes('alibaba') || message.includes('supplier')) {
      return "Great! You can connect your Alibaba supplier account to JokePan to:\n\n✓ Import products directly\n✓ Manage inventory\n✓ Track orders\n✓ Access exclusive pricing\n\nVisit our Alibaba page to get started: /alibaba";
    }

    // Minimum order
    if (message.includes('minimum') || message.includes('moq') || message.includes('min order')) {
      return "Our minimum order quantities vary by product:\n\n• Most Fashion items: 10 units minimum\n• Beauty products: 5-20 units minimum\n• Home décor: 5-15 units minimum\n\nWould you like to submit a bulk inquiry? I can help!";
    }

    // Payment & terms
    if (message.includes('payment') || message.includes('terms') || message.includes('how to pay')) {
      return "We accept multiple payment methods:\n\n💳 Credit/Debit Cards\n🏦 Bank Transfer\n💰 PayPal\n📲 Mobile Money\n\nWe offer flexible payment terms for qualified wholesale buyers. Contact our team for custom arrangements!";
    }

    // Shipping & delivery
    if (message.includes('shipping') || message.includes('delivery') || message.includes('how long')) {
      return "Shipping varies by location and order size:\n\n📦 Standard: 15-30 days\n🚚 Express: 7-10 days\n✈️ Air Freight: 3-5 days\n\nWe ship worldwide! Free shipping on orders over $500. Want a quote for your location?";
    }

    // Contact & support
    if (message.includes('contact') || message.includes('support') || message.includes('help') || message.includes('talk to')) {
      return "You can reach our wholesale team:\n\n📧 Email: wholesale@jokepan.com\n📞 Phone: +1-800-JOKEPAN\n💬 Live Chat: Available 9 AM - 6 PM EST\n\nOr submit a bulk inquiry form on our website!";
    }

    // Bulk inquiry
    if (message.includes('bulk') || message.includes('inquiry') || message.includes('order')) {
      return "Ready to place a bulk order? Here's what we need:\n\n1. Product category & specific items\n2. Quantity needed\n3. Your company details\n4. Timeline\n5. Special requirements\n\nVisit /bulk-inquiry to submit your request, or I can take your details now!";
    }

    // Quality & verification
    if (message.includes('quality') || message.includes('verify') || message.includes('certified')) {
      return "All our products are:\n\n✅ Verified for quality\n✅ Certified by suppliers\n✅ Inspected before shipment\n✅ Backed by satisfaction guarantee\n✅ Compliant with international standards\n\nWe partner only with trusted suppliers!";
    }

    // Default response
    return "Great question! I'm here to help with:\n\n• Pricing & discounts\n• Product information\n• Bulk orders\n• Shipping details\n• Payment methods\n• Alibaba integration\n\nWhat would you like to know more about?";
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Simulate bot thinking time
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getBotResponse(input),
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botResponse]);
      setIsLoading(false);
    }, 500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 rounded-full shadow-lg hover:shadow-xl transition"
        style={{
          width: '60px',
          height: '60px',
          background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)',
        }}
        title="Chat with us"
      >
        {isOpen ? (
          <X className="w-6 h-6 mx-auto text-white" />
        ) : (
          <MessageCircle className="w-6 h-6 mx-auto text-white" />
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 z-40 w-96 max-w-sm rounded-2xl shadow-2xl overflow-hidden" style={{ backgroundColor: '#FFFFFF' }}>
          {/* Header */}
          <div
            className="p-4 text-white flex justify-between items-center"
            style={{ background: 'linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%)' }}
          >
            <div>
              <h3 className="font-bold text-lg">JokePan Assistant</h3>
              <p className="text-sm text-white/80">Always here to help</p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-white/20 p-1 rounded"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="h-96 overflow-y-auto p-4 space-y-4 bg-white">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg text-sm whitespace-pre-wrap ${
                    message.sender === 'user'
                      ? 'bg-blue-100 text-blue-900'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                  style={
                    message.sender === 'user'
                      ? { backgroundColor: '#FF6B6B', color: 'white' }
                      : {}
                  }
                >
                  {message.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 px-4 py-2 rounded-lg">
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200 bg-white">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about products, pricing..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2"
                style={{ borderColor: '#FF6B6B' }}
              />
              <button
                onClick={handleSendMessage}
                disabled={!input.trim() || isLoading}
                className="p-2 rounded-lg disabled:opacity-50"
                style={{ backgroundColor: '#FF6B6B', color: 'white' }}
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
