import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { CheckCircle } from 'lucide-react';
import Link from 'next/link';

export default function AboutPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen bg-white">
        {/* Hero */}
        <div className="bg-linear-to-r from-blue-600 to-purple-600 text-white py-16 sm:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-6">About JokePan</h1>
            <p className="text-lg text-blue-100 max-w-3xl mx-auto">
              We&apos;re a platform dedicated to connecting creators with buyers and enabling seamless digital product commerce for modern businesses.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          {/* Mission */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-lg text-gray-600 mb-4">
                To empower creators and digital entrepreneurs by providing a world-class platform for selling premium digital products.
              </p>
              <p className="text-lg text-gray-600">
                We believe in making quality digital products accessible to everyone while providing creators with the tools they need to succeed.
              </p>
            </div>
            <div className="bg-blue-50 p-12 rounded-lg">
              <div className="text-5xl mb-4">🎯</div>
              <p className="text-gray-600">
                Since our founding, we&apos;ve helped over 5,000 customers access premium digital products with a combined value exceeding $2 million.
              </p>
            </div>
          </div>

          {/* Values */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: '💎',
                  title: 'Quality First',
                  desc: 'Every product is carefully curated and tested to ensure premium quality.',
                },
                {
                  icon: '🤝',
                  title: 'Customer Focus',
                  desc: 'Your satisfaction is our top priority. We listen and continuously improve.',
                },
                {
                  icon: '🚀',
                  title: 'Innovation',
                  desc: 'We constantly evolve our platform to better serve creators and buyers.',
                },
              ].map((value, idx) => (
                <div key={idx} className="bg-gray-50 p-8 rounded-lg text-center">
                  <div className="text-4xl mb-4">{value.icon}</div>
                  <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                  <p className="text-gray-600">{value.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="bg-blue-600 text-white rounded-lg p-12 mb-20">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold mb-2">5000+</div>
                <p className="text-blue-100">Happy Customers</p>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">150+</div>
                <p className="text-blue-100">Premium Products</p>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">50+</div>
                <p className="text-blue-100">Trusted Creators</p>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">100%</div>
                <p className="text-blue-100">Satisfaction Rate</p>
              </div>
            </div>
          </div>

          {/* Team */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold mb-12 text-center">Why Choose JokePan?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                'Curated selection of premium digital products',
                'Secure instant downloads and lifetime access',
                'Competitive pricing with volume discounts',
                'Dedicated support for bulk orders',
                'Regular updates and new product releases',
                'Community-driven product recommendations',
              ].map((feature, idx) => (
                <div key={idx} className="flex items-start gap-4">
                  <CheckCircle className="w-6 h-6 text-blue-600 shrink-0 mt-1" />
                  <span className="text-lg text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div className="bg-gray-50 p-12 rounded-lg text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Get Started?</h2>
            <p className="text-gray-600 mb-8 text-lg">
              Browse our collection of premium digital products or contact us for bulk inquiries.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/products"
                className="bg-blue-600 text-white px-8 py-3 rounded-lg font-bold hover:bg-blue-700 transition"
              >
                Browse Products
              </Link>
              <Link
                href="/bulk-inquiry"
                className="border-2 border-blue-600 text-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-blue-50 transition"
              >
                Bulk Inquiry
              </Link>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
